numb1 = 1234
numb2 = 4321

numb3 = numb1 + numb2

print ( numb3 )
