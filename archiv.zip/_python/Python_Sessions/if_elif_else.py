answer = raw_input ( 'is the sky red ? ')

if answer == 'no':
        print ' that`s what they want you to think !!!!'
elif answer =='yes':
        print ' ahh you see the truth enlighten one'
else:
	print ' I bet you think the earth is rouud !!!!! :) '
