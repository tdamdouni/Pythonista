# Python_Session

All the code for our Python Session

Session Date 11th Feb 2017

maths.py                                      #basic adding 2 numbers and displaying it
int-maths.py                                  #adding 2 numbers but using int
strings.py                                    #displaying strings
add_strings.py                                #adding two strings together
name.py                                       #a little fun with strings
name_input.py                                 #take you name as an input and displaying it as a string
if.py                                         #basic if statement
if_elif.py                                    #basic if else if statement
if_elif_else.py                               #basic if else if else statement
session1.py                                   #skynet


------------------------------------------------------------------------------------------------------------------------------------------

Session date 25th Feb 2017

dice.py                                       #Using some of the thing we learnt to make a dice game 
