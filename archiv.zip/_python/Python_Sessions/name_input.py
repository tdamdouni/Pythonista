name = raw_input ( ' What is your name travler ? ')

print ( ' Welcome to the grid ' + name + ' , enjoy your visit. ')
