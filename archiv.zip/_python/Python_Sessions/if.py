answer = raw_input ( 'is the sky red ? ')

if answer == 'no':
	print ' that`s what they want you to think !!!!'

