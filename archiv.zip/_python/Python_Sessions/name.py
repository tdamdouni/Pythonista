name = 'Lord Nikon'

print (' Welcome to skynet ' + name )

