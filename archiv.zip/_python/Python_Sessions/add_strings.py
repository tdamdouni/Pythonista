string1 = 'Hello '
string2 = 'World'

print (string1 + string2 )
